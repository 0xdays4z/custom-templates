// hooks/useApiOptions.ts
import { useMemo } from 'react';
import { useSettings } from '../contexts/SettingsProvider.tsx';
import { ApiOptions } from '../types.ts';

export const useApiOptions = (): { 
    apiOptions: ApiOptions | null; 
    isApiKeySet: boolean;
} => {
    const { apiKeys, openRouterModel, apiProvider } = useSettings();
    
    const isApiKeySet = useMemo(() => {
        if (apiProvider === 'openrouter') {
            return !!apiKeys.openrouter?.trim();
        }
        if (apiProvider === 'gemini') {
            return !!apiKeys.gemini?.trim();
        }
        return false;
    }, [apiKeys, apiProvider]);

    const apiOptions = useMemo(() => {
        if (!isApiKeySet) {
            return null;
        }
        if (apiProvider === 'openrouter') {
            return {
                apiKey: apiKeys.openrouter,
                model: openRouterModel,
                provider: 'openrouter',
            };
        }
        if (apiProvider === 'gemini') {
            return {
                apiKey: apiKeys.gemini,
                model: 'gemini-1.5-flash', // Or any other default Gemini model
                provider: 'gemini',
            };
        }
        return null;
    }, [isApiKeySet, apiKeys, openRouterModel, apiProvider]);

    return {
        apiOptions,
        isApiKeySet
    };
};